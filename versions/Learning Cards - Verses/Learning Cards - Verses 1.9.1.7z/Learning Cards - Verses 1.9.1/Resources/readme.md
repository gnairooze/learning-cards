﻿# Notes

1. This app depends on .net framework 4.6.1
2. In its config, you can set the following:
2.1. The location of the data file
2.2. The interval in minutes between each record
2.3. Play records in random order or standard order
2.4. Font size
2.5. Background color
2.6. Window position and if it is maximized
2.7. Content alignment
2.8. Location alignment


# Releases

## 1.9

1. add import from csv file function
2. move interval setting to submenu
3. change font increase and decrease to submenu
4. set alignment from context menu
5. add alignment in view settings message

## 1.8

1. Change location of buttons and card no

## 1.7.1

1. Add icon to the app. Previously it was added to the window only

## 1.7

1. Add icon to the app

## 1.6

1. Apply material design to UI

## 1.5

1. Fix load csv file with comma in its content